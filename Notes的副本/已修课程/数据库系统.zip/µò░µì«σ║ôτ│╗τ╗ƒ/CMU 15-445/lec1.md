1. Related database
2. storage
3. execution
4. concurrency control
5. revovery
6. distributed database
7. Potpourri



Relational Algebra

1. select
2. projection
3. union
4. intersection
5. difference
6. product
7. join

有点像集合运算



Observation

